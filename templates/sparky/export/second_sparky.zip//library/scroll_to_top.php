<script type="text/javascript" src="<?php echo $template_path ?>/js/scroll_to_top.js"></script>
<p id="back-top">
	<a hreg="#top"><span></span></a>
</p>