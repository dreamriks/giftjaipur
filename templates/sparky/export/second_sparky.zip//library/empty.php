<div class="cell mp_empty<?php echo $empty_no; ?>">
    <!-- EMPTY CELL -->
    <div>&nbsp;</div>
</div>